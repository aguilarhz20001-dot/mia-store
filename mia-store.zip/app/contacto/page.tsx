import { MapPin, MessageCircle } from "lucide-react";
import PageHero from "@/components/PageHero";
import FacebookIcon from "@/components/icons/FacebookIcon";
import InstagramIcon from "@/components/icons/InstagramIcon";
import {
  FACEBOOK_URL,
  INSTAGRAM_URL,
  WHATSAPP_DISPLAY,
  whatsappLink,
  DEFAULT_WHATSAPP_MESSAGE,
} from "@/lib/contact";

export const metadata = { title: "Contacto — Mia Store" };

export default function ContactoPage() {
  return (
    <>
      <PageHero
        eyebrow="Contacto"
        title="Hablemos"
        description="Escríbenos para resolver dudas, apartar productos o coordinar tu entrega."
      />

      <section className="max-w-3xl mx-auto px-5 sm:px-8 mt-12 grid gap-4 sm:grid-cols-2">
        <a
          href={whatsappLink(DEFAULT_WHATSAPP_MESSAGE)}
          target="_blank"
          rel="noopener noreferrer"
          className="card p-7 flex flex-col gap-3"
        >
          <span className="icon-badge"><MessageCircle size={26} /></span>
          <h2 className="font-semibold text-lg text-brand-ink">WhatsApp</h2>
          <p className="text-brand-pink-dark font-semibold">{WHATSAPP_DISPLAY}</p>
          <p className="text-sm text-brand-ink/70">La forma más rápida de comprar y consultar.</p>
        </a>

        <div className="card p-7 flex flex-col gap-3">
          <span className="icon-badge"><MapPin size={26} /></span>
          <h2 className="font-semibold text-lg text-brand-ink">Entregas y envíos</h2>
          <p className="text-brand-pink-dark font-semibold">Chimaltenango y todo el país</p>
          <p className="text-sm text-brand-ink/70">Entrega en punto de encuentro en Chimaltenango y paquetería al resto de Guatemala.</p>
        </div>

        <a href={FACEBOOK_URL} target="_blank" rel="noopener noreferrer" className="card p-7 flex items-center gap-4">
          <span className="icon-badge"><FacebookIcon className="w-6 h-6" /></span>
          <span className="font-semibold text-brand-ink">Facebook</span>
        </a>
        <a href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer" className="card p-7 flex items-center gap-4">
          <span className="icon-badge"><InstagramIcon className="w-6 h-6" /></span>
          <span className="font-semibold text-brand-ink">Instagram</span>
        </a>
      </section>
    </>
  );
}
